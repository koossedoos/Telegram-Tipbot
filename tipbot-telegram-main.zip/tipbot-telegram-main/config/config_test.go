// Copyright (c) 2019 Romano (Viacoin developer)
// Distributed under the MIT software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.
package config

import "testing"

func TestTest(t *testing.T) {
	GetViperConfig()
}
